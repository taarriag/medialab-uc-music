To use this package, add JavaWinampAPI.jar to you library in IDE
and put wpcom.dll in a Windows Path (it can be the directory where you are executing your program or 
<windowsdir>\system32 for example).
Javadoc directory contains documentation API.